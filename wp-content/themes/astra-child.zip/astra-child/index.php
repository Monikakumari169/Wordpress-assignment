<?php

get_header();

echo "Silence is golden";

get_fooetr();